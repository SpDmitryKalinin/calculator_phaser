declare const YaGames: {
    init(): Promise<any>;
  };