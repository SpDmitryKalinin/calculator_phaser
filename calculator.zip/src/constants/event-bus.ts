import * as Phaser from 'phaser';
const EventBus = new Phaser.Events.EventEmitter();

export default EventBus;
